<?php
	//Very important! in 'define', 'VN_' has to be replaced by the unique
	//name of the module to prevent the recurrence of lass languages 
	//variables or another modules languages variables
	//for example: 	For V1 module is used V1_
	//				For V2 module is used V2_
	//				For THEBESTMODULE module will be used THEBESTMODULE_
	define('VN_MODULE_TITTLE','Visualization tittle');//this var appears in index.php
?> 