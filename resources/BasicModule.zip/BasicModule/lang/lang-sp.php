<?php
	//Muy importante!!! en el define, 'VN_' tiene que ser sustituido por el nombre �nico del m�dulo 
	//para que no se repitan variables de lenguajes de glass o de otros m�dulos
	//ej: 	Para V1 se utiliza V1_
	//		para V2 se utiliza V2_
	//		Para THEBESTMODULE se utilizar� THEBESTMODULE_
	define('VN_MODULE_TITTLE','T�tulo de la visualizaci�n'); //Esta variable aparece en index.php
?> 
